#include "Counter.hpp"
#include "Observer.hpp"
#include "LongFormat.hpp"
#include "DoubleFormat.hpp"
#include "Observable.hpp"
#include <vector>
#include <iostream>

int main() {

	Counter c1;
	DoubleFormat df1;
	LongFormat lf1;
	
	std::cout << "Current counter value: " << c1.GetCounter() << std::endl; //0
	c1.AddObserver(&df1);
	c1.IncreaseCounter(&df1); 
	c1.AddObserver(&lf1);
	c1.IncreaseCounter(&lf1);

	c1.NotifyObservers(&lf1);

	c1.Update(&lf1);
	
	std::cout << "\nCurrent counter value: " << c1.GetCounter() << std::endl; //2
	c1.AddObserver(&df1);
	c1.IncreaseCounter(&df1);

	std::cout << "\nCurrent counter value: " << c1.GetCounter() << std::endl; //3
	c1.DecreaseCounter(&df1);

	std::cout << "\nCurrent counter value : " << c1.GetCounter() << std::endl; //2
	c1.DeleteObserver();
	c1.DecreaseCounter(&df1);

	std::cout << "\nCurrent counter value: " << c1.GetCounter() << std::endl; //1
	c1.DeleteObserver();
	c1.DecreaseCounter(&df1);
	c1.Update(&df1);
	std::cout << "\nCurrent counter value: " << c1.GetCounter() << std::endl; //0
	
	return 0;
}