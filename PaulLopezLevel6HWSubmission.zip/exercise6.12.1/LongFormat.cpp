#ifndef LongFormat_CPP
#define LongFormat_CPP
#include <iostream>
#include "Observable.hpp"
#include "Observer.hpp"
#include "LongFormat.hpp"
#include "Counter.hpp"
#include <iomanip>

void LongFormat::Update(Observable* s) {
	Counter* c = dynamic_cast<Counter*>(s);
	std::cout << "Counter value in Long Format: " << static_cast<long>(c->GetCounter()) << std::endl;
}


#endif