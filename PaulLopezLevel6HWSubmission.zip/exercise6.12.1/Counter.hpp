#ifndef Counter_HPP
#define Counter_HPP
#include "Observable.hpp"

class Observer;
class Counter : public Observable {

private:
	int counterCount;
public:

	Counter();
	~Counter();

	int GetCounter();
	void IncreaseCounter(Observer* ob);
	void DecreaseCounter(Observer* ob);
	void AddObserver(Observer* ob);
	void DeleteObserver();
	void Update(Observer* ob);
};

//#ifndef Counter_cpp // Must be the same name as in source file #define
//#include "Counter.cpp"
//#endif

#endif