#ifndef Observer_HPP
#define Observer_HPP
#include "Observable.hpp"

class Observer {
public:
	//Observer();
	//~Observer();
		
	virtual void Update(Observable* s) = 0;
	
};

//#ifndef Observer_cpp // Must be the same name as in source file #define
//#include "Observer.cpp"
//#endif

#endif