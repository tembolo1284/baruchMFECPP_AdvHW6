#ifndef Observable_HPP
#define Observable_HPP
#include <vector>

class Observer;

class Observable {
private:
	std::vector<Observer*> m_vec;

public:

	Observable();
	~Observable();

	virtual void AddObserver(Observer* ob) = 0;
	virtual void DeleteObserver() = 0;
	void NotifyObservers(Observer* ob);
	friend class Counter;
};

//#ifndef Observable_cpp // Must be the same name as in source file #define
//#include "Observable.cpp"
//#endif

#endif