#ifndef Counter_CPP
#define Counter_CPP
#include "Counter.hpp"
#include "Observer.hpp"
#include <iostream>

Counter::Counter() : counterCount(0) {}

Counter::~Counter() {}

int Counter::GetCounter() {
	return counterCount;
}

void Counter::IncreaseCounter(Observer* ob) {
	counterCount += 1;
	std::cout << "Counter increased by 1." << std::endl;
	Observable::NotifyObservers(ob);
}

void Counter::DecreaseCounter(Observer* ob) {
	counterCount -= 1;
	std::cout << "Counter decreased by 1." << std::endl;
	Observable::NotifyObservers(ob);
}

void Counter::AddObserver(Observer* ob) {
	std::cout << "Counter Add Observer call." << std::endl;
	m_vec.push_back(ob);
}

void Counter::DeleteObserver() {
	std::cout << "Counter Delete Observer call." << std::endl;
	m_vec.pop_back();
}

void Counter::Update(Observer* ob) {
	std::cout << "Counter Update call." << std::endl;
	ob->Update(this);
}


#endif