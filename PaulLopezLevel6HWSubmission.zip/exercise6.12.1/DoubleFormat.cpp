#ifndef DoubleFormat_CPP
#define DoubleFormat_CPP
#include <iostream>
#include "Observable.hpp"
#include "Observer.hpp"
#include "DoubleFormat.hpp"
#include "Counter.hpp"
#include <iomanip>


void DoubleFormat::Update(Observable* s) {
	Counter* c = new Counter;
	c = dynamic_cast<Counter*>(s);
	std::cout << "Counter value in Double Format: " << static_cast<double>(c->GetCounter()) << std::endl;

}
#endif