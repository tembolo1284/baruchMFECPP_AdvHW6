#ifndef Observable_CPP
#define Observable_CPP
#include <vector>
#include <iostream>
#include "Observable.hpp"
#include "Observer.hpp"

Observable::Observable() {}
Observable::~Observable() {}

//void Observable::AddObserver(Observer* ob) {
//	std::cout << "Subject Attach call." << std::endl;
//	m_vec.push_back(ob);
//}

//void Observable::DeleteObserver() {
//	std::cout << "Subject Detach call." << std::endl;
//	m_vec.pop_back();
//}

void Observable::NotifyObservers(Observer* ob) {
	std::cout << "\n--------Observeable Notify Observers call.--------\n" << std::endl;
	for (auto elem : m_vec) {
		elem->Update(this);
	}
}

#endif