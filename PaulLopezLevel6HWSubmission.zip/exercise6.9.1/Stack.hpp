#ifndef Stack_HPP
#define Stack_HPP
#include <iostream>
#include <vector>
//#include "StackState.hpp"

class StackState;
class EmptyState;
class FullState;
class NotFullNotEmptyState;

class Stack {

private:
	friend class StackState;
	friend class EmptyState;
	friend class FullState;
	friend class NotFullNotEmptyState;

	std::vector<int> vec;
	int currIndex;
	StackState* currState;
	int cap;
		
	void Init(int size);
public:
	Stack();//default ctor that sets to size = 1
	Stack(int size);
				
	void Push(int elem);
	int Pop();
	void ChangeState(StackState* newState);

	void Print();
	~Stack(){}
};
#endif