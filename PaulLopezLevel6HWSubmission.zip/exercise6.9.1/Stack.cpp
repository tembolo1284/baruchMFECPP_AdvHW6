#ifndef Stack_CPP
#define Stack_CPP
#include "Stack.hpp"
#include "EmptyState.hpp"
#include "NotFullNotEmptyState.hpp"
#include "FullState.hpp"

class StackState;

		Stack::Stack() {
			Init(1);
		}
		
		Stack::Stack(int size) {
			Init(size);
		}

		/*Check if the size is at least 1. If less set the size to 1. Create the array for the elements with the given size.
		Set the current index to 0 (first element to be set). Set the state to a new instance of EmptyState.*/
		void Stack::Init(int size) {
			currIndex = 0;
			EmptyState es;
			currState = es.Instance();

			if (size >= 1) {
				cap = size;
			}
			else {
				throw std::exception("Exception!You need to enter a size greater than 0");
			}
			//if (vec.size() < 1) {
			//	vec.resize(1); //resize to 1 if size is < 1.
			//}
			//else {
			//	vec.resize(size);
			//}
		}

		void Stack::ChangeState(StackState* ns) {
			currState = ns;
		}

		void Stack::Push(int elem) {
			currState->Push(this, elem);
		}

		int Stack::Pop() {
			return currState->Pop(this);
		}

		void Stack::Print() {
			std::cout << "Stack elements: ";
			for (auto elem : vec) {
				std::cout << elem << ", ";
			}
			std::cout << "\n";
		}


#endif
