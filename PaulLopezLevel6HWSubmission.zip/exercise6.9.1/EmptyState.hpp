#ifndef EMPTYSTATE_HPP
#define EMPTYSTATE_HPP
#include <iostream>
#include <vector>
#include "StackState.hpp"
#include "Singleton.hpp"


class EmptyState: public StackState {

public:
	
	friend class Singleton<EmptyState>;
	friend class StackState;
	friend class Stack;

	void Push(Stack* st, int elem);
	int Pop(Stack* s);

	StackState* Instance();

	~EmptyState() {}

};


#endif