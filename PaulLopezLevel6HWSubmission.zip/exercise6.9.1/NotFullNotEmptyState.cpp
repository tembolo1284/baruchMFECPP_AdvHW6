#ifndef NOTFULLNOTEMPTYSTATE_CPP
#define NOTFULLNOTEMPTYSTATE_CPP
#include <iostream>
#include <vector>
#include "EmptyState.hpp"
#include "FullState.hpp"
#include "NotFullNotEmptyState.hpp"
#include "StackState.hpp"
#include "Stack.hpp"
#include "Singleton.hpp"
#include <exception>
/*The Pop() method changes the current state to EmptyState if the current index==1. 
Then it should call the Pop()method of the base class.
The Push() method should call the push() method of the base class. Then it should change the current state to FullState 
if the current index==array.length.*/


StackState* NotFullNotEmptyState::Instance() { // Return a unique instance
    return Singleton<NotFullNotEmptyState>::instance();
}


void NotFullNotEmptyState::Push(Stack* s, int elem) {// Push an element on the stack
    StackState::Push(s,elem);

    if (s->currIndex == s->cap) {
        FullState fs;
        ChangeState(s, fs.Instance());
    }
}

int NotFullNotEmptyState::Pop(Stack* s) {
    StackState::Pop(s);
    if (s->currIndex == 1) {
        EmptyState es;
        ChangeState(s, es.Instance());
    }
    else {
        NotFullNotEmptyState nfne;
        ChangeState(s, nfne.Instance());
    }

    return s->vec[s->currIndex];
}



#endif