#include <iostream>
#include <stdio.h>
#include "Stack.hpp"
#include "StackState.hpp"
#include "EmptyState.hpp"
#include "FullState.hpp"
#include "NotFullNotEmptyState.hpp"
#include "Singleton.hpp"


int main() {

	Stack s1;
	Stack s2(3);

	try {
		//s1.Pop(); //will get an exception trying to pop an empty array
		s1.Push(5); 
		s1.Print();
		//s1.Push(7); //will get an exception for pushing onto a full stack

		s2.Push(4); //start adding ints to s2 stack
		s2.Push(2);
		s2.Push(3);
		s2.Print();
		s2.Push(11);  //should get exception from trying to push onto full stack

	}
	catch(std::exception e) {
		std::cout << e.what() << std::endl;
	}
	return 0;
}