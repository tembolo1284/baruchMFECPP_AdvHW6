#ifndef EMPTYSTATE_CPP
#define EMPTYSTATE_CPP
#include <iostream>
#include <vector>
#include "EmptyState.hpp"
#include "FullState.hpp"
#include "NotFullNotEmptyState.hpp"
#include "StackState.hpp"
#include "Stack.hpp"
#include "Singleton.hpp"
#include <exception>

/*The Pop() method should throw an exception since you cannot pop from an empty stack.
The Push() method should call the Push() method of the base class. Then it should change the current state. 
If the current index==array.length then it should set the current state to FullState. 
Else it should set the current state to NotFullNotEmptyState.*/

StackState* EmptyState::Instance() { // Return a unique instance
    return Singleton<EmptyState>::instance();
}

void EmptyState::Push(Stack* s, int elem) {// Push an element on the stack
    StackState::Push(s, elem);

    if (s->currIndex == s->cap ) { 
        FullState fs;
        ChangeState(s, fs.Instance());
    }
    else {
        NotFullNotEmptyState nfne;
        ChangeState(s, nfne.Instance());
    }
}

int EmptyState::Pop(Stack* s) {
    //std::cout << "Exception: Pop for empty array isn't allowed.";
    throw std::exception("Exception: Can't pop an empty array.");
    return 1;
}



#endif