#ifndef STACKSTATE_HPP
#define STACKSTATE_HPP
#include <iostream>
#include <vector>
#include "Singleton.hpp"

class Stack;

class StackState{

public:

	friend class Stack;

	void ChangeState(Stack* s, StackState* st);
	virtual void Push(Stack* s, int elem) = 0;
	virtual int Pop(Stack* s) = 0;
	
};


#endif