#ifndef FullState_HPP
#define FullState_HPP
#include <iostream>
#include <vector>
#include "StackState.hpp"


class FullState : public StackState {
	

public:
	friend class Singleton<FullState>;

	void Push(Stack* s, int elem);
	int Pop(Stack* s);
	StackState* Instance();

	~FullState() {}

};


#endif