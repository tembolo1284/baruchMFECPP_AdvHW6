#ifndef NotFullNotEmptyState_HPP
#define NotFullNotEmptyState_HPP
#include <iostream>
#include <vector>
#include "StackState.hpp"


class NotFullNotEmptyState : public StackState {
	
public:
	friend class Singleton<NotFullNotEmptyState>;
	void Push(Stack* s, int elem);
	int Pop(Stack* s);

	StackState* Instance();

	~NotFullNotEmptyState() {}

};


#endif