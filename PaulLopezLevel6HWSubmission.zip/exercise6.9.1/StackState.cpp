#ifndef STACKSTATE_CPP
#define STACKSTATE_CPP
#include <iostream>
#include <vector>
#include "StackState.hpp"
#include "Stack.hpp"


/*The Push() method has an �element� as argument. It stores the passed element in the array at the current index and then 
increases the current index.
The Pop() method returns an �element�. The method should first decrease the current index and then return the element at the new 
current index.*/

void StackState::ChangeState(Stack* s, StackState* st) {
	s->currState = st;
}
	void StackState::Push(Stack* s, int elem) {
		s->vec.push_back(elem);
		s->currIndex += 1;
	}
	
	int StackState::Pop(Stack* s) {
		s->currIndex -= 1;
		return s->vec[s->currIndex];
	}



#endif