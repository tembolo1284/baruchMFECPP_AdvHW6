#ifndef FULLSTATE_CPP
#define FULLSTATE_CPP
#include <iostream>
#include <vector>
#include "EmptyState.hpp"
#include "FullState.hpp"
#include "NotFullNotEmptyState.hpp"
#include "StackState.hpp"
#include "Stack.hpp"
#include "Singleton.hpp"
#include <exception>
/*The Pop() method should change the current state to EmptyState if the current index==1. 
Otherwise it should change to NotFullNotEmptyState. Then call the Pop() method of the base class.
The Push() method should throw an exception since we can�t push onto a full stack.*/

StackState* FullState::Instance() { // Return a unique instance
    return Singleton<FullState>::instance();
}

void FullState::Push(Stack* s, int elem) {// Push an element on the stack
    throw std::exception("Exception! Can't push onto a full stack.");
}

int FullState::Pop(Stack* s) {
    StackState::Pop(s);
    if (s->currIndex == 1) {
        EmptyState es;
        ChangeState(s, es.Instance());
    }
    else {
        NotFullNotEmptyState nfne;
        ChangeState(s, nfne.Instance());
    }
    
    return s->vec[s->currIndex];
}



#endif