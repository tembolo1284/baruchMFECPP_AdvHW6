#ifndef SHAPEFACTORY_HPP
#define SHAPEFACTORY_HPP
#include <iostream>
#include <string>
#include "Point.hpp"
#include "Line.hpp"
#include "Circle.hpp"


namespace PAULLOPEZ {
	namespace CAD {

		class ShapeFactory {

		public:

			virtual Circle* CreateCircle() = 0;
			//virtual void CreateCircle(double rad, Point& p) = 0;

			virtual Line* CreateLine() = 0;
			//virtual void CreateLine(Point& p1, Point& p2) = 0;

			virtual Point* CreatePoint() = 0;
			//virtual void CreatePoint(double x, double y) = 0;

			virtual ~ShapeFactory() {}
		};
	}
}

#endif