#ifndef CONSOLESHAPEFACTORY_CPP
#define CONSOLESHAPEFACTORY_CPP
#include <iostream>
#include <string>
#include "ConsoleShapeFactory.hpp"
//#include "Point.hpp"
//#include "Line.hpp"
//#include "Circle.hpp"
//#include "Shape.hpp"

namespace PAULLOPEZ {
	namespace CAD {

		Circle* ConsoleShapeFactory::CreateCircle() {
			double radius;
			double x;
			double y;
			std::cout << "Please input a radius for your circle (double)." << std::endl;
			std::cin >> radius;
			std::cout << "Please specify x coordinate for the center of your circle." << std::endl;
			std::cin >> x;
			std::cout << "Please specify y coordinate for the center of your circle." << std::endl;
			std::cin >> y;
			Point p(x, y);
			Circle c1(radius, p);
			Circle* c1Ptr = &c1;
			//*c1Ptr = c1;
			c1Ptr->Print();
			return c1Ptr;
		}

		Line* ConsoleShapeFactory::CreateLine() {
			double x1;
			double y1;
			double x2;
			double y2;
			std::cout << "Please specify x coordinate for the first point." << std::endl;
			std::cin >> x1;
			std::cout << "Please specify y coordinate for the first point." << std::endl;
			std::cin >> y1;
			std::cout << "Please specify x coordinate for the second point." << std::endl;
			std::cin >> x2;
			std::cout << "Please specify y coordinate for the second point." << std::endl;
			std::cin >> y2;
			Point p1(x1, y1);
			Point p2(x2, y2);
			Line l1(p1, p2);
			Line* l1Ptr = &l1;
			l1Ptr->Print();
			return l1Ptr;

		}

		Point* ConsoleShapeFactory::CreatePoint() {
			double x;
			double y;
			std::cout << "Please specify x coordinate for the point." << std::endl;
			std::cin >> x;
			std::cout << "Please specify y coordinate for the point." << std::endl;
			std::cin >> y;

			Point p(x, y);
			Point* pPtr = &p;
			pPtr->Print();
			return pPtr;
		
		}

	}
}
#endif