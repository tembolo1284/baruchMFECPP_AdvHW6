#include <iostream>
#include <stdio.h>
#include "Point.hpp"
#include "Line.hpp"
#include "Circle.hpp"
#include "Shape.hpp"
#include "ShapeFactory.hpp"
#include "ConsoleShapeFactory.hpp"

using namespace PAULLOPEZ::CAD;
namespace PLC = PAULLOPEZ::CAD;


int main() {
	double a = 2.25;
	Point p1(1, 2);
	Point p2(-1, 3);
	Point p3(0, 5);
	Line l1(p1, p2);
	Line l2(p2, p3);
	Circle c1(a, p1);

	ConsoleShapeFactory csf1;
	
	//you'll have to enter in some numbers for this program!
	csf1.CreateCircle();
	csf1.CreateLine();
	csf1.CreatePoint();

	return 0;
}