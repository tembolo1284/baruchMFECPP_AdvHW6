#ifndef CONSOLESHAPEFACTORY_HPP
#define CONSOLESHAPEFACTORY_HPP
#include <iostream>
#include <string>
#include "ShapeFactory.hpp"

namespace PAULLOPEZ {
	namespace CAD {
		class ConsoleShapeFactory : public ShapeFactory {

		public:
			Circle* CreateCircle();
			
			Line* CreateLine();
			
			Point* CreatePoint();
			
			virtual ~ConsoleShapeFactory() {}
		};

	}
}


#endif