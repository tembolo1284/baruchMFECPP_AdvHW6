#ifndef NoFundsException_hpp
#define NoFundsException_hpp
#include "Exception.hpp"
#include <string>

class NoFundsException : public Exception { //OutOfBounds is derived class of ArrayException
private:
	int index;
public:
	NoFundsException(int index); //constructor with int param
	std::string GetMessage() const;
};



#endif
