#ifndef NoFundsException_cpp
#define NoFundsException_cpp
#include "NoFundsException.hpp"
#include <string>


NoFundsException::NoFundsException(int index = -1) {} //constructor with int param
std::string NoFundsException::GetMessage() const {
	return "You do not have enough funds for this withdrawal.\n";
}

#endif
