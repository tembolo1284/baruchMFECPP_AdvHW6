#ifndef RealAccount_cpp
#define RealAccount_cpp
#include <iostream>
#include "Exception.hpp"
#include "NoAccessException.hpp"
#include "NoFundsException.hpp"
#include "Account.hpp"
#include "RealAccount.hpp"

RealAccount::RealAccount() : balance(0) {}
RealAccount::RealAccount(double amt) : balance(amt) {} //ctor with balance amount
RealAccount::RealAccount(const RealAccount& acc) : balance(acc.balance) {}//copy ctor

RealAccount::~RealAccount() {} //destructor

void RealAccount::Withdraw(const double amt) {
	std::cout << "Withdrawing..." << std::endl;
	if (balance - amt < 0) {
		throw NoFundsException(amt);
	}
	else {
		balance -= amt * 1.0;
		std::cout << "Withdraw complete!" << std::endl;
	}

}

double RealAccount::GetBalance() const {
	return balance;
}


#endif