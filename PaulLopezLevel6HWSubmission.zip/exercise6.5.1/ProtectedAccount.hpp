#ifndef ProtectedAccount_hpp
#define ProtectedAccount_hpp
#include "Account.hpp"
#include <string>

class ProtectedAccount : public Account {
private:
	int balance;
	std::string pwd;

public:
	ProtectedAccount();
	ProtectedAccount(double amt, std::string pwd); //ctor with balance amount and password
	ProtectedAccount(const ProtectedAccount& acc); //copy ctor

	~ProtectedAccount(); //destructor
	void Withdraw(const double amt);
	double GetBalance() const;
	void Withdraw(const double amt, std::string pwd);
	double GetBalance(std::string pwd) const;
};


#endif
