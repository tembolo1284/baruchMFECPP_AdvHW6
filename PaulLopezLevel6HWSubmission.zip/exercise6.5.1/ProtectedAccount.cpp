#ifndef ProtectedAccount_cpp
#define ProtectedAccount_cpp
#include <iostream>
#include "Exception.hpp"
#include "NoAccessException.hpp"
#include "NoFundsException.hpp"
#include "Account.hpp"
#include "ProtectedAccount.hpp"

ProtectedAccount::ProtectedAccount() : balance(0) {}
ProtectedAccount::ProtectedAccount(double amt, std::string pwd) : balance(amt), pwd(pwd) {} //ctor with balance amount
ProtectedAccount::ProtectedAccount(const ProtectedAccount& acc) : balance(acc.balance) {}//copy ctor

ProtectedAccount::~ProtectedAccount() {} //destructor

void ProtectedAccount::Withdraw(const double amt, std::string pwd) {
	if (this->pwd == pwd) {
		std::cout << "Withdrawing..." << std::endl;
		if (balance - amt < 0) {
			throw NoFundsException(amt);
		}
		else {
			balance -= amt;
			std::cout << "Withdraw complete!" << std::endl;
		}
	}
	else {
		throw NoAccessException(-1);
	}
}

void ProtectedAccount::Withdraw(const double amt) {
	std::cout << "Please provide a password to withdraw funds";
	throw NoAccessException(-1);
}

double ProtectedAccount::GetBalance(std::string pwd) const {
	if (this->pwd == pwd) {
		return balance;
	}
	else {
		throw NoAccessException(-1);
	}
}

double ProtectedAccount::GetBalance() const {
	std::cout << "Please provide a password to view balance";
		throw NoAccessException(-1);
		return 1.5;
	
}


#endif