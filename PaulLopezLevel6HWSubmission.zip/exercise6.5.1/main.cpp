#include <iostream>
#include <string>
#include "Account.hpp"
#include "RealAccount.hpp"
#include "ProtectedAccount.hpp"
#include "Exception.hpp"
#include "NoAccessException.hpp"
#include "NoFundsException.hpp"

int main() {

	try {
		RealAccount ra1(100.00);

		std::cout << "Current balance for ra1 = " << ra1.GetBalance() << std::endl;
		ra1.Withdraw(95);
		std::cout << "Current balance for ra1 = " << ra1.GetBalance() << std::endl;
		//ra1.Withdraw(25); //will get no funds exception  

		ProtectedAccount pa1(100.00, "ab3d");
		std::cout << "Current balance for pa1 = " << pa1.GetBalance("ab3d") <<std::endl;
		//std::cout << "Current balance for pa1 = " << pa1.GetBalance("woof") << std::endl; //will get no access exception
		pa1.Withdraw(75,"ab3d");
		std::cout << "Current balance for pa1 = " << pa1.GetBalance("ab3d") << std::endl;
		//pa1.Withdraw(75, "ab3d"); //will get no funds exception
		//pa1.Withdraw(75, "hello"); //will get no access exception
		

	}
	catch (NoAccessException& nae) {
		std::cout << "No Access Exception has occurrred." << std::endl << nae.GetMessage() << std::endl;
	}
	catch (NoFundsException& nfe) {
		std::cout << "No Funds Exception has occurrred." << std::endl << nfe.GetMessage() << std::endl;
	}
	catch (...) {
		std::cout << "An unhandled exception has occurred.";
	}

	return 0;
}