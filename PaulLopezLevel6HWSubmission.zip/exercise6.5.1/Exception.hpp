#ifndef Exception_hpp
#define Exception_hpp
#include <string>
#include <iostream>

class Exception { 
public:

	virtual std::string GetMessage() const = 0;
};

#endif
