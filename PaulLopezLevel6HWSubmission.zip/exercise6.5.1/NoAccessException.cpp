#ifndef NoAccessException_cpp
#define NoAccessException_cpp
#include "NoAccessException.hpp"
#include <string>


NoAccessException::NoAccessException(int index = -1) {} //constructor with int param
std::string NoAccessException::GetMessage() const {
	return "You do not have the proper permissions for this action.\n";
}

#endif