#ifndef RealAccount_hpp
#define RealAccount_hpp
#include "Account.hpp"
#include <string>

class RealAccount : public Account {
private:
	int balance;

public:
	RealAccount();
	RealAccount(double amt); //ctor with balance amount
	RealAccount(const RealAccount& acc); //copy ctor

	~RealAccount(); //destructor
	void Withdraw(const double amt);
	double GetBalance() const;
};


#endif
