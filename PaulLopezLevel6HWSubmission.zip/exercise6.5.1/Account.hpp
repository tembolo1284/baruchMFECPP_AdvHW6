#ifndef Account_hpp
#define Account_hpp

class Account {

private:

public:
	virtual void Withdraw(const double amt) = 0 ;
	virtual double GetBalance() const = 0 ;

};

#endif
