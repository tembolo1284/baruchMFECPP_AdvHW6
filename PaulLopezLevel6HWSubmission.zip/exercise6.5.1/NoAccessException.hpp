#ifndef NoAccessException_hpp
#define NoAccessException_hpp
#include "Exception.hpp"
#include <string>

class NoAccessException : public Exception { 
private:
	int index;
public:
	NoAccessException(int index); //constructor with int param
	std::string GetMessage() const;
};


#endif
