#include <iostream>
#include <stdio.h>
#include "Point.hpp"
#include "Line.hpp"
#include "Shape.hpp"
#include "OriginPoint.hpp"
#include "Singleton.hpp"
#include "ShapeComposite.hpp"


using namespace PAULLOPEZ::CAD;
namespace PLC = PAULLOPEZ::CAD;

void Print(ShapeComposite& sc) {
	auto it = sc.begin();
	std::cout << "\nPrinting: ";
	while (it != sc.end()) {
		(*it)->Print();
		it++;
	}
}

int main() {
	
	Point p1(1, 2);
	Point p2(2, -1);
	Line l1(p1, p2);

	Shape* s1;
	Shape* s2;
	Shape* s3;
	s1 = &p1;
	s2 = &p2;
	s3 = &l1;
	
	ShapeComposite sc1;
	ShapeComposite sc2;

	sc1.AddShape(s1);
	sc1.AddShape(s2);
	sc1.AddShape(s3);

	sc2.AddShape(&sc1);
	sc2.AddShape(s1);

	std::cout << "sc1 size = " << sc1.count() << std::endl;
	std::cout << "sc2 size = " << sc2.count() << std::endl;
	Print(sc1);
	Print(sc2);

	//Create a program to test the newly added functionality. 
	//The easiest way would be to use the previous program and call a copy constructor for the composite.
	
	ShapeComposite sc3(sc1);
	std::cout << "sc3 size = " << sc3.count() << std::endl;
	std::cout << "--------------sc3--------------";
	Print(sc3);
	
	return 0;
}