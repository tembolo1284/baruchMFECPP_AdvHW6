#ifndef ShapeComposite_CPP
#define ShapeComposite_CPP
#define _USE_MATH_DEFINES
#include "ShapeComposite.hpp"
//#include "Shape.hpp"
#include <cmath>
#include <sstream>
		
	ShapeComposite::ShapeComposite() {}

	ShapeComposite::ShapeComposite(const ShapeComposite& srcShapeList) {
		//m_shapeList = srcShapeList.m_shapeList;
		auto iter = srcShapeList.m_shapeList.begin();
		while (iter != srcShapeList.m_shapeList.end()) {
			m_shapeList.push_back(*iter);
			iter++;
		}
	}// copy constructor

	ShapeComposite& ShapeComposite::operator = (const ShapeComposite& srcShapeList) {
		if (this == &srcShapeList) {
			return *this;
		}
		
		auto iter = srcShapeList.m_shapeList.begin();
		while (iter != srcShapeList.m_shapeList.end()) {
			m_shapeList.push_back(*iter);
			iter++;
		}
		return *this;
	}// Assignment operator


	Shape* ShapeComposite::Clone() const {
		ShapeComposite newSC(*this);
		Shape* result = &newSC;
		return result;
	}

	


#endif
