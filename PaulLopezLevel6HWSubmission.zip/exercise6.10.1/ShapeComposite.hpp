#ifndef ShapeComposite_HPP
#define ShapeComposite_HPP
#include "Shape.hpp"
#include <list>

namespace PAULLOPEZ {
	namespace CAD {
		typedef std::list<Shape*>::iterator iter;
		typedef std::list<Shape*>::const_iterator const_Iter;

		//class ShapeVisitor;

		class ShapeComposite : public Shape {
		private:
			std::list<Shape*> m_shapeList;
		public:
			ShapeComposite();

			void AddShape(Shape* s) {
				m_shapeList.push_back(s);
			}

			ShapeComposite(const ShapeComposite& srcShapeList);// = delete;    // copy constructor
			ShapeComposite& operator = (const ShapeComposite& srcShapeList); // = delete;// Assignment operator

			std::list<Shape*>::iterator begin() {
				auto result = m_shapeList.begin();
				return result;
			}

			std::list<Shape*>::iterator end() {
				auto result = m_shapeList.end();
				return result;
			}

			int count() {
				int size = std::distance(m_shapeList.begin(), m_shapeList.end());
				return size;
			}
			void Draw() const { std::cout << "I'm in Shape Composite."; }

			Shape* Clone() const;

			void Accept(ShapeVisitor& sv);


		};


	}
}

//#ifndef ShapeComposite_cpp // Must be the same name as in source file #define
//#include "ShapeComposite.cpp"
//#endif


#endif