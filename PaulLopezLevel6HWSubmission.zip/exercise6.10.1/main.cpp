#include <iostream>
#include <stdio.h>
#include "Point.hpp"
#include "Line.hpp"
#include "Circle.hpp"
#include "Shape.hpp"
#include "OriginPoint.hpp"
#include "Singleton.hpp"
#include "ShapeComposite.hpp"
#include "ShapeVisitor.hpp"
#include "PrintVisitor.hpp"

using namespace PAULLOPEZ::CAD;
namespace PLC = PAULLOPEZ::CAD;

void Print(ShapeComposite& sc) {
	auto it = sc.begin();
	std::cout << "\nPrinting Shape Composite: ";
	while (it != sc.end()) {
		(*it)->Print();
		it++;
	}
}

int main() {
	
	try {
		double r = 1.5;
		Point p1(1, 2);
		Point p2(2, -1);
		Line l1(p1, p2);
		Circle c1(r, p1);
		ShapeComposite sc1;
		ShapeComposite sc2;
		Shape* s1;
		s1 = &p1;
		Shape* s2;
		s2 = &l1;
		Shape* s3;
		s3 = &c1;
		Shape* s4;
		s4 = &p2;

		Shape* s5;
		s5 = &sc1;

		sc1.AddShape(s1);
		sc1.AddShape(s2);
		sc1.AddShape(s3);

		sc2.AddShape(s1);
		sc2.AddShape(s5);


		Print(sc1);

		std::cout << "------------- Visit and Accept time -------------" << std::endl;
		PrintVisitor pv1;
		PrintVisitor pv2;
		p1.Accept(pv1); // method #2
		pv1.visit(p1); // method #1
		

		pv1.visit(l1); // method #1
		l1.Accept(pv1); // method #2

		pv1.visit(c1); // method #1
		c1.Accept(pv1); // method #2

		
		sc1.AddShape(s4);
		pv1.visit(sc1); //method #1
		sc1.Accept(pv1); //method #2

		std::cout << "-----------sc2 Accept and Visit---------" << std::endl;
		sc2.Accept(pv2);
		pv2.visit(sc2);
	}
	catch (std::exception e) {
		std::cout << e.what() << std::endl;
	}
	catch (...) {
		std::cout << "Unhandled Exception has occured." << std::endl;
	}


	
	return 0;
}