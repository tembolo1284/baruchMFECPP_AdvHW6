#include <iostream>
#include "Point.hpp"
#include "Shape.hpp"
#include "DistanceStrategy.hpp"
#include "ApproximateDistance.hpp"
#include "ExactDistance.hpp"

using namespace PAULLOPEZ::CAD;
namespace PLC = PAULLOPEZ::CAD;

int main() {
	
	Point p1(1, 2);
	Point p2(2, -1);

	//std::cout << "p1 to origin = " << p1.Distance() << std::endl;
	//std::cout << "p1 to p2 = " << p1.Distance(p2) << std::endl;
	//p1.SetStrategy("Approx");

	DistanceStrategy* dsExact = new ExactDistance;
	DistanceStrategy* dsApprox = new ApproximateDistance;
	std::cout << "p1 to p2 = " << p1.Distance(p2, *dsExact) << std::endl;

	std::cout << "p1 to p2 = " << p1.Distance(p2, *dsApprox) << std::endl;

	//I like having the distanceStrategy as a param better. I think it is more readable and you know which
	//calc method you are using. I really like how I separate it out from the Point class. Very cool!
	
	return 0;
}