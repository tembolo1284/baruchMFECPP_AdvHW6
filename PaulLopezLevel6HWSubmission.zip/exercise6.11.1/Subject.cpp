#ifndef Subject_CPP
#define Subject_CPP
#include <vector>
#include <iostream>
#include "Subject.hpp"
#include "Observer.hpp"

Subject::Subject() {}
Subject::~Subject() {}

void Subject::Attach(Observer* ob) {
	std::cout << "Subject Attach call." << std::endl;
	m_vec.push_back(ob);
}

void Subject::Detach() {
	std::cout << "Subject Detach call." << std::endl;
	m_vec.pop_back();
}

void Subject::Notify(Observer* ob) {
	std::cout << "Subject Notify call." << std::endl;
	for (auto elem : m_vec) {
		elem->Update(this);
	}
}

#endif