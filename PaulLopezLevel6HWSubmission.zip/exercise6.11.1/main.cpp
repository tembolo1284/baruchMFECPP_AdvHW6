#include "Counter.hpp"
#include "Observer.hpp"
#include "LongFormat.hpp"
#include "DoubleFormat.hpp"
#include "Subject.hpp"
#include <vector>
#include <iostream>

int main() {

	Counter c1;
	DoubleFormat df1;
	LongFormat lf1;
	
	std::cout << "Current counter value: " << c1.GetCounter() << std::endl; //0
	c1.Attach(&df1);
	c1.IncreaseCounter(&df1); 
	c1.Attach(&lf1);
	c1.IncreaseCounter(&lf1);

	std::cout << "\nCurrent counter value: " << c1.GetCounter() << std::endl; //2
	c1.Attach(&df1);
	c1.IncreaseCounter(&df1);

	std::cout << "\nCurrent counter value: " << c1.GetCounter() << std::endl; //3
	c1.DecreaseCounter(&df1);

	std::cout << "\nCurrent counter value : " << c1.GetCounter() << std::endl; //2
	c1.Detach();
	c1.DecreaseCounter(&df1);

	std::cout << "\nCurrent counter value: " << c1.GetCounter() << std::endl; //1

	return 0;
}