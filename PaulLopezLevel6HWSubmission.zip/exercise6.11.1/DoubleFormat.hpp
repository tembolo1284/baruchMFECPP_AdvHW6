#ifndef DoubleFormat_HPP
#define DoubleFormat_HPP
#include "Subject.hpp"
#include "Observer.hpp"

class DoubleFormat : public Observer {
public:
	void Update(Subject* s);
};

//#ifndef Observer_cpp // Must be the same name as in source file #define
//#include "Observer.cpp"
//#endif

#endif