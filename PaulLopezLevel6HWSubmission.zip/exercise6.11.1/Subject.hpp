#ifndef Subject_HPP
#define Subject_HPP
#include <vector>

class Observer;

class Subject {
private:
	std::vector<Observer*> m_vec;

public:
	
	Subject();
	~Subject();

	virtual void Attach(Observer* ob);
	void Detach();
	void Notify(Observer* ob);
};



//#ifndef Subject_cpp // Must be the same name as in source file #define
//#include "Subject.cpp"
//#endif

#endif