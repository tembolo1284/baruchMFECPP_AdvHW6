#ifndef ShapeComposite_HPP
#define ShapeComposite_HPP
#include "Shape.hpp"
#include <list>
typedef std::list<Shape*>::iterator iter;
typedef std::list<Shape*>::const_iterator const_Iter;
 

		class ShapeComposite :public Shape {
		private:
			std::list<Shape*> m_shapeList;

			ShapeComposite(const ShapeComposite& srcShapeList);// = delete;    // copy constructor
			ShapeComposite& operator = (const ShapeComposite& srcShapeList); // = delete;// Assignment operator
		public:
			ShapeComposite() {}
			
			void AddShape(Shape* s) {
				m_shapeList.push_back(s);
			}
			
			iter begin() {
				auto result = m_shapeList.begin();
				return result;
			}

			iter end() {
				auto result = m_shapeList.end();
				return result;
			}

			int count() {
				int size = std::distance(m_shapeList.begin(), m_shapeList.end());
				return size;
			}
			void Draw() const { std::cout << "I'm in Shape Composite."; }
		};
		

#endif