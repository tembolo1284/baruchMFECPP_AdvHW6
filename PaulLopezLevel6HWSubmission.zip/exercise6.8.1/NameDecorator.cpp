#ifndef NAMEDECORATOR_CPP
#define NAMEDECORATOR_CPP
#include <iostream>
#include <string>
#include "NameDecorator.hpp"

namespace PAULLOPEZ {
	namespace CAD {


		NameDecorator::NameDecorator() : ShapeDecorator(), name("") {};
		
		NameDecorator::NameDecorator(Shape* sourceSh, std::string n) : ShapeDecorator(sourceSh), name(n) {
			//Shape* sh(sourceSh);
			//NameDecorator::ShapeDecorator sd(sh);
			//name = n;
		};

		Shape* NameDecorator::GetShape() const {
			std::cout << "Name is: " << name << std::endl;
			Shape* result(ShapeDecorator::GetShape());
			result->Print();
			return result;
		}
		Shape* NameDecorator::SetShape(Shape* sourceShape, std::string n) {
			name = n;
			Shape* result(sourceShape);
			return result;
		}

		void NameDecorator::Draw() const { // Draw.
			cout << "ShapeDecorator Draw function call.";
		}

		Shape* NameDecorator::Clone() const {
			NameDecorator nd(*this);
			Shape* result = &nd;
			return result;
		}

		std::string NameDecorator::GetName() const {
			return name;
		}
		void NameDecorator::SetName(std::string s) {
			name = s;
		}

	}
}

#endif