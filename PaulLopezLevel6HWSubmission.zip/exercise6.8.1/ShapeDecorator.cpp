#ifndef SHAPEDECORATOR_CPP
#define SHAPEDECORATOR_CPP
#include <iostream>
#include <string>
#include "ShapeDecorator.hpp"

namespace PAULLOPEZ {
	namespace CAD {


		ShapeDecorator::ShapeDecorator() : sh(nullptr) {};
		ShapeDecorator::ShapeDecorator(Shape* sourceShape) : sh(sourceShape) {};

		Shape* ShapeDecorator::GetShape() const{
			return sh;
		}
		Shape* ShapeDecorator::SetShape(Shape* sourceShape) {
			sh = sourceShape;
			return sh;
		}

		void ShapeDecorator::Draw() const { // Draw.
			cout << "ShapeDecorator Draw function call.";
		}

		Shape* ShapeDecorator::Clone() const {
			ShapeDecorator sd(*this);
			Shape* result = &sd;
			return result;
		}

	}
}

#endif