#ifndef SHAPEDECORATOR_HPP
#define SHAPEDECORATOR_HPP
#include <iostream>
#include <string>
#include "Shape.hpp"

namespace PAULLOPEZ {
	namespace CAD {
		class ShapeDecorator : public Shape {

		private:
			Shape* sh;
		public:

			ShapeDecorator(); //: sh(nullptr) {};
			ShapeDecorator(Shape* sourceShape);// : sh(sourceShape) {};

			Shape* GetShape() const;
			Shape* SetShape(Shape* sourceShape);

			Shape* Clone() const;
			void Draw() const;

			virtual ~ShapeDecorator() {}

		};

	}
}


#endif