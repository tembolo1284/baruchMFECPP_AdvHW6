#include <iostream>
#include <stdio.h>
#include "Point.hpp"
#include "Line.hpp"
#include "Circle.hpp"
#include "Shape.hpp"
#include "ShapeFactory.hpp"
#include "ConsoleShapeFactory.hpp"
#include "ShapeDecorator.hpp"
#include "NameDecorator.hpp"

using namespace PAULLOPEZ::CAD;
namespace PLC = PAULLOPEZ::CAD;


int main() {
	double a = 2.25;
	Point p1(1, 2);
	Point p2(-1, 3);
	Point p3(0, 5);
	Line l1(p1, p2);
	Line l2(p2, p3);
	Circle c1(a, p1);

	Shape* p1Ptr = &p1;
	Shape* l1Ptr = &l1;
	Shape* c1Ptr = &c1;

	NameDecorator nd1(p1Ptr, "Pretty p1");
	NameDecorator nd2(l1Ptr, "Pretty l1");
	NameDecorator nd3(c1Ptr, "Pretty c1");

	nd1.GetShape();
	nd2.GetShape();
	nd3.GetShape();

	nd2.SetShape(p1Ptr, "Now it is pretty point p1");

	nd2.GetShape();

	nd3.SetName("Hello to you circle in nd3");
	std::cout << "New nd3 name is: " << nd3.GetName() << std::endl;

	return 0;
}