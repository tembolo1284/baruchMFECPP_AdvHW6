#ifndef NAMEDECORATOR_HPP
#define NAMEDECORATOR_HPP
#include <iostream>
#include <string>
#include "ShapeDecorator.hpp"

namespace PAULLOPEZ {
	namespace CAD {

		class NameDecorator: public ShapeDecorator {

		private:
			std::string name;
		public:

			NameDecorator(); 
			NameDecorator(Shape* sourceShape, std::string sourceName);

			Shape* GetShape() const;
			Shape* SetShape(Shape* sourceShape, std::string sourceName);
			std::string GetName() const;
			void SetName(std::string s);


			Shape* Clone() const;
			void Draw() const;


			virtual ~NameDecorator() {}

		};

	}
}


#endif