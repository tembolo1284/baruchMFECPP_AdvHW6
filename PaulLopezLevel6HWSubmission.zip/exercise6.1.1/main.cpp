#include <iostream>
#include <stdio.h>
#include "Point.hpp"
#include "Line.hpp"
#include "Circle.hpp"
#include "Shape.hpp"


using namespace PAULLOPEZ::CAD;
namespace PLC = PAULLOPEZ::CAD;


int main() {
	double a = 2.5;
	Point p1(1, 2);
	Point p2(2, -1);
	Line l1(p1, p2);
	Circle c1(a, p2);

	p1.Print();
	l1.Print();
	c1.Print();

	return 0;
}