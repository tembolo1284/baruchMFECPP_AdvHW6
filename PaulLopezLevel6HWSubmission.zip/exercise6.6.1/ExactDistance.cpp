#ifndef ExactDistance_CPP
#define ExactDistance_CPP
#include <iostream>
//#include "Point.hpp"
//#include "Shape.hpp"
#include "ExactDistance.hpp"
#include "DistanceStrategy.hpp"

namespace PAULLOPEZ {
	namespace CAD {

		double ExactDistance::Distance(const Point& p1, const Point& p2) {
			std::cout << "Exact Distance Method: ";
			double result = sqrt(pow(p2.X() - p1.X(), 2.0) + pow(p2.Y() - p1.Y(), 2.0)); // ((x2-x1)^2 + (y2-y1)^2)^0.5
			return result;
		}
	}
}

#endif