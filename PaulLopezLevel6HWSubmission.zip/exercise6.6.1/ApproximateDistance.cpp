#ifndef ApproximateDistance_CPP
#define ApproximateDistance_CPP
#include <iostream>
//#include "Point.hpp"
//#include "Shape.hpp"
#include "ApproximateDistance.hpp"
#include "DistanceStrategy.hpp"

namespace PAULLOPEZ {
	namespace CAD {

		double ApproximateDistance::Distance(const Point& p1, const Point& p2) {
			std::cout << "Approximate Distance Method: ";
			double result = abs(p2.X() - p1.X()) + abs(p2.Y() - p1.Y()); 
			return result;
		}
	}
}

#endif