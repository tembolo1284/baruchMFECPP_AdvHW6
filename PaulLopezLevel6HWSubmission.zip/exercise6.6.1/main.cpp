#include <iostream>
#include "Point.hpp"
#include "Shape.hpp"
#include "DistanceStrategy.hpp"
#include "ApproximateDistance.hpp"
#include "ExactDistance.hpp"

using namespace PAULLOPEZ::CAD;
namespace PLC = PAULLOPEZ::CAD;

int main() {
	
	Point p1(1, 2);
	Point p2(2, -1);

	std::cout << "p1 to origin = " << p1.Distance() << std::endl; //we have exact distance by default
	std::cout << "p1 to p2 = " << p1.Distance(p2) << std::endl;

	p1.SetStrategy("Approx");

	std::cout << "p1 to p2 = " << p1.Distance(p2) << std::endl;

	p1.SetStrategy("Exact");

	std::cout << "p1 to p2 = " << p1.Distance(p2) << std::endl;


	//Great pattern to use if you have many different ways to run a certain implementation of an algorithm.
	//It is also useful and easier to maintain by separating the methodology out of the class (or classes) itself.
	return 0;
}