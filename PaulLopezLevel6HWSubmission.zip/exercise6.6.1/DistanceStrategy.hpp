#ifndef DistanceStrategy_HPP
#define DistanceStrategy_HPP
#include <iostream>
//#include "Point.hpp"
//#include "Shape.hpp"


namespace PAULLOPEZ {
	namespace CAD {

		class Point; // fwd declare Point
		class DistanceStrategy {
		public:
			virtual double Distance(const Point& p1, const Point& p2) = 0;
		};
	}
}

#endif