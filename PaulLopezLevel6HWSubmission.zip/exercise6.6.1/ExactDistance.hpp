#ifndef ExactDistance_HPP
#define ExactDistance_HPP
#include <iostream>
#include "Point.hpp"
#include "Shape.hpp"
#include "DistanceStrategy.hpp"

namespace PAULLOPEZ {
	namespace CAD {

		class ExactDistance : public DistanceStrategy {
		public:
			double Distance(const Point& p1, const Point& p2);
		};
	}
}


//#ifndef ExactDistance_cpp 
//#include "ExactDistance.cpp"
//#endif


#endif