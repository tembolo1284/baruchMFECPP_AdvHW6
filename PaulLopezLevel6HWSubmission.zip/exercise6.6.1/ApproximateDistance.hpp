#ifndef ApproximateDistance_HPP
#define ApproximateDistance_HPP
#include <iostream>
#include "Point.hpp"
#include "Shape.hpp"
#include "DistanceStrategy.hpp"

namespace PAULLOPEZ {
	namespace CAD {

		class ApproximateDistance : public DistanceStrategy {
		public:
			double Distance(const Point& p1, const Point& p2);
		};
	}
}

//#ifndef ApproximateDistance_cpp 
//#include "ApproximateDistance.cpp"
//#endif


#endif