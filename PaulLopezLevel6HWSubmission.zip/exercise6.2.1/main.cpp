#include <iostream>
#include <stdio.h>
#include "Point.hpp"
#include "Shape.hpp"
#include "OriginPoint.hpp"
#include "Singleton.hpp"


using namespace PAULLOPEZ::CAD;
namespace PLC = PAULLOPEZ::CAD;


int main() {
	double a = 2.5;
	Point p1(1, 2);
	Point p2(2, -1);
	OriginPoint op1;
	
	std::cout << "p1: " << p1.ToString() << std::endl;
	std::cout << "op1 instance: " << *op1.instance() <<std::endl; //(0,0)
	std::cout << "p1 to op1 distance: " << p1.Distance() << std::endl; //sqrt(5)

	(op1.instance())->X(1.0);
	(op1.instance())->Y(2.0); //change origin point op1 to be the same as p1 above.

	std::cout << "op1 instance: " << *op1.instance() << std::endl; //(1.0,2.0)
	std::cout << "p1 to op1 distance: " << p1.Distance() << std::endl; // distance should now be 0 since p1 == op1






	


	
	return 0;
}